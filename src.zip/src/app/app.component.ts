import { Component,OnInit } from '@angular/core';
import { data, data2 } from './data.service';
import { DataInterface } from './data-interface';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import {FormGroup,FormBuilder, Validators} from "@angular/forms"

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  
  form!:FormGroup;
  constructor(private fb : FormBuilder){}

  ngOnInit(): void {
      this.form = this.fb.group(
      {
        item:['',Validators.required]
      }
      )
  }


  users: DataInterface[] = data;
  users2: DataInterface[] = [];
  
  drop1(event: CdkDragDrop<DataInterface[]>): void {
    console.log(event.item.data);

    if (event.previousContainer !== event.container) {
    }
    // moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    transferArrayItem(
      event.previousContainer.data, // Source array
      event.container.data,         // Destination array
      event.previousIndex,          // Index in the source array
      event.currentIndex            // Index in the destination array
    );
  }

  drop(event: CdkDragDrop<DataInterface[]>): void {
    transferArrayItem(
      event.previousContainer.data, // Source array
      event.container.data,         // Destination array
      event.previousIndex,          // Index in the source array
      event.currentIndex            // Index in the destination array
    );
  }

  AddButton(): void {
    this.users.push({
      name: this.form.value.item
    });
  }
  
}




