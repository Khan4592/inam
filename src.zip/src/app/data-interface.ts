export interface DataInterface {
    // id:number;
    name:string;
}
