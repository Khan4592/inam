import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {CdkDropListGroup,CdkDropList,CdkDrag,CdkDragDrop} from '@angular/cdk/drag-drop'
import { AppComponent } from './app.component';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {Validator, ReactiveFormsModule} from "@angular/forms"
@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    ReactiveFormsModule,MatButtonModule,MatIconModule,MatInputModule,BrowserModule,CdkDropListGroup,CdkDropList,CdkDrag,MatFormFieldModule, BrowserAnimationsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
