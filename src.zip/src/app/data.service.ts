export const data = [
  {
    id: 1,
    name: 'Samaria',
  },
  {
    id: 2,
    name: 'Gauthier',
  },
  {
    id: 3,
    name: 'Mellisa',
  },
  {
    id: 4,
    name: 'Arabela',
  },
  {
    id: 5,
    name: 'Devon',
  },
  {
    id: 6,
    name: 'Stacee',
  },
  {
    id: 7,
    name: 'Federica',
  },
  {
    id: 8,
    name: 'Jecho',
  },
  {
    id: 9,
    name: 'Alasteir',
  },
  {
    id: 10,
    name: 'Elston',
  },
];


export const data2 = [
  {
    id: 1,
    name: 'inam',
  },
  {
    id: 2,
    name: 'aqr',
  },
];