export const data = [
    {
      id: 1,
      name: 'Samaria',
      content_body: 'asdd',
      disp: "block",
      checked:false,

    },
    {
      id: 2,
      name: 'Gauthier',
      content_body: 'asdd',
      disp: 'block',
      checked:false,


    },
    
  ];
  
  
  export const data2 = [
    {
      id: 1,
      name: 'inam',
      disp: true,
      checked:true,

    },
    {
      id: 2,
      name: 'aqr',
      disp: true,
      checked:true,
    },
  ];