export interface DataInterface {
    // id:number;
    name:string;
    content_body: string;
    disp: string;
    checked:boolean;

}
